export default {
  'react': 'React',
  'react-dom': 'ReactDOM',
  '@depay/web3-constants': 'Web3Constants',
  '@depay/web3-blockchains': 'Web3Blockchains',
}
